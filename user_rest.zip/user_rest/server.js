const express = require('express');
require('dotenv').config();
const app = express();
const bodyParser = require('body-parser');
// console.log(process.env.port);
const port = process.env.port || 4000;
app.use(bodyParser.json());
const Joi = require('joi');

// user rest api crud based with joi validation

let usersData = [
  {
    id: 101,
    username: "Ramu gupta",
    password: "ramu12@",
    confirm_password: "ramu12@",
    address: 'North humayupur ,gorakhpur',
    email: "ramugupta808118@gmail.com",
    contact: 8081186483,
    birthDay: '15-07-2003'

  },
  {
    id: 102,
    username: "Deepak",
    password: "ramu12@",
    confirm_password: "ramu12@",
    address: 'Ali nagar ,gorakhpur',
    email: "rudra901@gmail.com",
    contact: 7896329173,
    birthDay: '15-07-2003'
  },
  {
    id: 103,
    username: "Nirmal  giri",
    password: "ramu12@",
    confirm_password: "ramu12@",
    address: 'buxipur ,gorakhpur',
    email: "nirmalgiri420@gmail.com",
    contact: 9006522725,
    birthDay: '15-07-2003'
  },
  {
    id: 104,
    username: "Abhimanyu",
    password: "ramu12@",
    confirm_password: "ramu12@",
    address: 'rustampur,gorakhpur',
    email: "ramugupta808118@gmail.com",
    contact: 7010246366,
    birthDay: '15-07-2003'
  }
];

app.get('/user/find/:index', (req, res) => {
  // res.json([req.params.index]);
  const schema = Joi.object({
    index: Joi.number().min(100).max(104).required()
  });
  const validation = schema.validate(req.params);
  if (validation.error) {
    res.status(403).json(validation.error.message);
  }
  Inc_user = usersData.find((u) => u.id == req.params.index);
  if (!Inc_user) {
    res.json("404 error not  found")
  }
  else {
    res.json(Inc_user)
  }

});


app.post('/user/add', (req, res) => {
  const schema = Joi.object({
    username: Joi.string().min(3),
    password: Joi.string().minOfSpecialCharacters(2).minOfLowercase(2).minOfUppercase(2).minOfNumeric(2).noWhiteSpaces()
      .onlyLatinCharacters()
      .required(),
    confirm_password: Joi.ref('password'),
    address: Joi.string().min(10).max(25),
    email: Joi.string().trim().email({
      maxDomainSegments: 2,
      minDomainSegments: 1,
      tlds: { allow: ['com', 'net', 'yahoo', 'outlook'] }
    }),
    contact: Joi.number().min(10).required(),
    birthDay: Joi.date().max('2004-01-23').iso()
  });
  validation = schema.validate(req.body);
  if (validation.error) {
    res.status(403).json(validation.error.message)
  }
  let newUser = {
    id: usersData[usersData.length - 1].id + 1,
    username: req.body.username,
    password: req.body.password,
    confirm_password: req.body.confirm_password,
    address: req.body.address,
    email: req.body.email,
    contact: req.body.contact,
    birthDay: req.body.birthDay
  }
  usersData.push(newUser);
  console.log(newUser);


  res.json(usersData);
});
app.post('/user/update', (req, res) => {
  const schema = Joi.object({
    username: Joi.string().min(3),
    password: Joi.string().minOfSpecialCharacters(2).minOfLowercase(2).minOfUppercase(2).minOfNumeric(2).noWhiteSpaces()
      .onlyLatinCharacters()
      .required(),
    confirm_password: Joi.ref('password'),
    address: Joi.string().min(10).max(25),
    email: Joi.string().trim().email({
      maxDomainSegments: 2,
      minDomainSegments: 1,
      tlds: { allow: ['com', 'net', 'yahoo', 'outlook'] }
    }),
    contact: Joi.number().min(10).required(),
    birthDay: Joi.date().max('2004-01-23').iso()
  });
  validation = schema.validate(req.body);
  if (validation.error) {
    res.status(403).json(validation.error.message)
  }
  let newUser = {
    id: games.length + 1,
    username: req.body.name,
    address: req.body.address,
    email: req.body.email,
    contact: req.body.contact
  }
  usersData.push(newUser);


  res.json(usersData);
});
//deletiong a user by query parameter
app.delete('/user/delete', (req, res) => {
  let IndexOfDeletingItems = parseInt(req.query.id);
  console.log(IndexOfDeletingItems);
  let findUser = usersData.find((user) => {
    if (user.id === IndexOfDeletingItems) {
      return user;
    }
  });
  if (findUser) {
    ind = usersData.indexOf(findUser);
    usersData.splice(ind, 1);
    res.json(usersData);
  }
  else {
    res.json("404 not found user");
  }

});


//put method is used to update some elements
app.put('/user/update/:id', (req, res) => {
  //incoming id through request params
  Inc_id = parseInt(req.params.id);
  const schema = Joi.object({
    username: Joi.string().min(3),
    password: Joi.string()
      .minOfSpecialCharacters(2)
      .minOfLowercase(2)
      .minOfUppercase(2)
      .minOfNumeric(2)
      .noWhiteSpaces()
      .onlyLatinCharacters(),
    confirm_password: Joi.ref('password'),
    address: Joi.string().min(10).max(25),
    email: Joi.string().trim().email({
      maxDomainSegments: 2,
      minDomainSegments: 1,
      tlds: { allow: ['com', 'net', 'yahoo', 'outlook'] }
    }),
    contact: Joi.number().min(10).required(),
    birthDay: Joi.date().max('2004-01-23').iso()
  });
  validation = schema.validate(req.body);
  if (validation.error) {
    res.status(403).json(validation.error.message)
  }
  //retieve and finding the game to update

  let Ext_user = usersData.find((g) => g.id === (Inc_id))
  //   for (let index = 0; index < games.length; index++) {
  //     if (games[index].id === Inc_id) {
  //       Ext_game = games[index];
  //       break;
  //     }
  //   }
  Inc_name = req.body.name || Ext_user.username;
  Inc_address = req.body.address
  Inc_email = req.body.email
  Inc_contact = req.body.contact
  //validate game 
  if (!Ext_user) {
    res.status(503).json("unable to update ")
  }
  Ext_user.name = Inc_name
  res.json(games)
});


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
});